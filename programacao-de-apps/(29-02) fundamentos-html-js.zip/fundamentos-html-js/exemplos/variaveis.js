function exemploVariaveis() {
  let nome = 'João'; // usar LET quando a var'ivel for alterada
  nome = 'Maria';

  const idade = 30; // usar CONST quando a var'ivel NAO for alterada

  const possuiFaculdade = true;
  const preco = 99.9;

  // alert(idade);

  const meuNome = 'João';
  const minhaIdade = 30;

  minhaIdade = 32;

  let minhaComidaFavorita;
  alert(minhaComidaFavorita);
  minhaComidaFavorita = 'Lasanha';
  alert(minhaComidaFavorita);
}
