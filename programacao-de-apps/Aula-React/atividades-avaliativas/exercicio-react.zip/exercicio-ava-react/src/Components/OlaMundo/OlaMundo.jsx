import "./OlaMundo.css"

const OlaMundo = () => {
  return (
    <div className="ola__mundo">OlaMundo</div>
  )
}

export default OlaMundo