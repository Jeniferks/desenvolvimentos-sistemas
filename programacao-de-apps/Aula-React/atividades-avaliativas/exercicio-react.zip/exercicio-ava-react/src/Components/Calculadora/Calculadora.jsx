import "./Calculadora.css"

const Calculadora = () => {
  return (
    <div>Calculadora</div>
  )
}

export default Calculadora