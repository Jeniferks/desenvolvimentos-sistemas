
const NomesOrdenados = () => {
    return (
        <div>NomesOrdenados</div>
    )
}

export default NomesOrdenados