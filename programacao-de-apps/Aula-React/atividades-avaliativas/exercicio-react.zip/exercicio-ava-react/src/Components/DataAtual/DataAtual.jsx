import "./DataAtual.css"

const DataAtual = () => {
    return (
        <div className="data__atual">DataAtual</div>
    )
}

export default DataAtual