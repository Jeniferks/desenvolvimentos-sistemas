

const MinutoAtual = () => {
    return (
        <div>MinutoAtual</div>
    )
}

export default MinutoAtual