import "./DataCompletaAtual.css"

const DataCompletaAtual = () => {
    return (
        <div>DataCompletaAtual</div>
    )
}

export default DataCompletaAtual