
const Multiplicacao = () => {
  return (
    <div>Multiplicacao</div>
  )
}

export default Multiplicacao