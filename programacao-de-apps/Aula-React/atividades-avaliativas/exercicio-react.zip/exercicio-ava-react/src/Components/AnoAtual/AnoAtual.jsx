import "./AnoAtual.css"

const AnoAtual = () => {
    return (
        <div className="ano__atual">AnoAtual</div>
    )
}

export default AnoAtual