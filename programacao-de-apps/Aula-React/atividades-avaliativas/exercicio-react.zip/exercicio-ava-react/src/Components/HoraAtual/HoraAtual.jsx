

const HoraAtual = () => {
  return (
    <div>HoraAtual</div>
  )
}

export default HoraAtual