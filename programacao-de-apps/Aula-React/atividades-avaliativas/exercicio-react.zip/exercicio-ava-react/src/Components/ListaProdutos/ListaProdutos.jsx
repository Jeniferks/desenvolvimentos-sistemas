

const ListaProdutos = () => {
  return (
    <div>ListaProdutos</div>
  )
}

export default ListaProdutos