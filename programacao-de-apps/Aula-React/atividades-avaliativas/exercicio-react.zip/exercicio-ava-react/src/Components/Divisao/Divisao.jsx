

const Divisao = () => {
  return (
    <div>Divisao</div>
  )
}

export default Divisao