import './App.css'
import OlaMundo from './Components/OlaMundo/OlaMundo'
import DataAtual from './Components/DataAtual/DataAtual'

function App() {
  

  return (
    <>
      <OlaMundo/>
      <DataAtual/>
      
    </>
  )
}

export default App
